Nysa AWS
----------

ready to go library for interacting with AWS Elastic Container Service

Key Features
------------
- easy to read / maintain deployment scripts
- deploy multiple services with a single command
- creates services with private (service-discovery) and internet-facing Application Load Balancers
- route53 integration when combining an ALB
- cluster specific or service customizable environment variables

